﻿using System;

class Parcial2
{
    static void Main(string[] args)
    {
        string[] alumnos = new string[10];
        int[] punteo = new int[10];
        int opcion;

        for (int i = 0; i < 10; i++)
        {
            Console.Write("Ingrese el nombre del alumno " + (i + 1) + ": ");
            alumnos[i] = Console.ReadLine();

            Console.Write("Ingrese el punteo " + (i + 1) + " (0-100): ");
            string input = Console.ReadLine();

            while (!int.TryParse(input, out punteo[i]) || punteo[i] < 0 || punteo[i] > 100)
            {
                Console.WriteLine("El punteo ingresado no es válida.");
                Console.Write("Ingrese el punteo del alumno " + (i + 1) + ": ");
                input = Console.ReadLine();
            }
        }

        do
        {
            Console.WriteLine("Menú para ver el punteo y el promedio:");
            Console.WriteLine("1: Ver el nombre y punteo de alumnos que ganaron el curso.");
            Console.WriteLine("2: Ver nombre y punteo de alumnos que No ganaron el curso.");
            Console.WriteLine("3: Mostrar el promedio de notas del grupo.");
            Console.WriteLine("4: Salir ");

            Console.Write("Ingrese una opción: ");
            string input = Console.ReadLine();

            while (!int.TryParse(input, out opcion))
            {
                Console.WriteLine("La opción ingresada no es válida.");
                Console.Write("Ingrese una opción: ");
                input = Console.ReadLine();
            }

            switch (opcion)
            {
                case 1:
                    MostrarGanados(alumnos, punteo);
                    break;
                case 2:
                    MostrarPerdidos(alumnos, punteo);
                    break;
                case 3:
                    MostrarPromedio(punteo);
                    break;
                case 4:
                    Console.WriteLine("Gracias por usar mi programa.");
                    break;
            }
        } while (opcion!= 4);
    }

    static void MostrarGanados(string[] nombres, int[] notas)
    {
        Console.WriteLine("Alumnos que ganaron el curso:");
        for (int i = 0; i < nombres.Length; i++)
        {
            if (notas[i] >= 60)
            {
                Console.WriteLine(nombres[i] + " - " + notas[i]);
            }
        }
    }

    static void MostrarPerdidos(string[] alumnos, int[] punteo)
    {
        Console.WriteLine("Alumnos que no ganaron el curso:");
        for (int i = 0; i < alumnos.Length; i++)
        {
            if (punteo[i] < 60)
            {
                Console.WriteLine(alumnos[i] + " - " + punteo[i]);
            }
        }
    }

    static void MostrarPromedio(int[] punteo)
    {
        int suma = 0;
        for (int i = 0; i < punteo.Length; i++)
        {
            suma += punteo[i];
        }
        double promedio = (double)suma / punteo.Length;
        Console.WriteLine("Promedio de punteo del grupo: " + promedio);
    }
}
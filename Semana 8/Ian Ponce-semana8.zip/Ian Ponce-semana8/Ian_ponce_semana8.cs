﻿using System;

class Ian_Ponce_semana8
{
    static void Main(string[] args)
    {
        // Ingreso del número
        Console.WriteLine("Ingrese un número entero positivo (no mayor a 6 cifras): ");
        int n = int.Parse(Console.ReadLine());

        // Inicializar variables
        bool esPrimo = true;
        int divisor = 2;

        // Bucle para verificar divisibilidad
        while (divisor <= Math.Sqrt(n) && esPrimo)
        {
            if (n % divisor == 0)
            {
                esPrimo = false;
            }
            divisor++;
        }

        // Mostrar resultado
        if (esPrimo)
        {
            Console.WriteLine("El número {0} es primo.", n);
        }
        else
        {
            Console.WriteLine("El número {0} no es primo.", n);
        }
    }
}
